﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestTap.Shared.Data
{
    public class TestModel: BindingModel
    {
        private int _id;

        public int Id
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
                EvRaisePropertyChanged("Id");
            }
        }
    }
}
