﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text;
using TestTap.Shared.Data;

namespace TestTap.Shared.ViewModel
{
    public class TestViewModel : BindingModel
    {
        private ObservableCollection<TestModel> _TestList= new ObservableCollection<TestModel>();
        public ObservableCollection<TestModel> TestList
        {
            get { return _TestList; }
            set
            {
                _TestList = value;
                EvRaisePropertyChanged("TestList");
            }
        }
        public TestViewModel()
        {
            for (int i = 0; i < 100; i++)
            {
                TestList.Add(new TestModel { Id = i });
            }
        }
    }
}
